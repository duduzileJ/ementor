﻿namespace ementor.Models
{
    public class Subject
    {
        public Student Student { get; set; }
        public Tutor Tutor { get; set; }
        public Grade? Grade { get; set; }
        public string Title { get; set; }
        public int Duration { get; set; }
    }
}
