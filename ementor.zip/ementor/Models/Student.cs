﻿
namespace ementor.Models
{
    public class Student
    {
        
        public int ID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        
    }
    public class EmentorList
    {
        public List<Student> students { get; set; }
        public List<Student> findAll()
        {
            students = new List<Student>
            {
                new Student()
                {
                    ID = 1,
                    FirstName = "Duduzile",
                    LastName = "January"
                },
                new Student()
                {
                    ID = 2,
                    FirstName = "Ntuthuko",
                    LastName = "February"
                },
                new Student()
                {
                    ID = 3,
                    FirstName = "Nqobile",
                    LastName = "March"
                },
                new Student()
                {
                    ID = 4,
                    FirstName = "Simingaye",
                    LastName = "April"
                }
            };
            return students;
        }
        public Student student(int id)
        {
            List<Student> stu = findAll();
            var _students = stu.Where(a => a.ID == id).FirstOrDefault();

            return _students;
        }
    }
}
