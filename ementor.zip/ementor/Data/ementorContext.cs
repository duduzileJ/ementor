﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using ementor.Models;
using Microsoft.AspNetCore.Identity;
using System.Data;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;

namespace ementor.Data
{
    public class ementorContext : DbContext
    {
        public ementorContext(DbContextOptions<ementorContext> options)
            : base(options)
        {
        }

        public DbSet<ementor.Models.Student>? Student { get; set; }


    }
    public class ementorDbContext : IdentityDbContext<IdentityUser>
    {
        public ementorDbContext(DbContextOptions<ementorContext> options)
            : base(options)
        {

        }
    }


}
